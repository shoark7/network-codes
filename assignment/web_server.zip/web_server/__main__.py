from web_server_container import server

server.serve()
